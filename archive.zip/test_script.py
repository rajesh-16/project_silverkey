from netmiko import ConnectHandler
import os,sys,re


device = {'host':'R1',
	  'device_type':'cisco_ios',
	  'username':'cisco',
	  'password':'cisco'}



def test_bgp():
	try:
		bgp_status=ConnectHandler(**device).send_command('show ip bgp summary')
		bgp_neighbor=ConnectHandler(**device).send_command('show ip bgp neighbors')
#		bgp_details=ConnectHandler(**device).send_command(command_list)
#		f=open('/home/rajesh/project_silverkey/bgp_details.txt','w')
#		f.write(bgp_details)
#	with open('/home/rajesh/project_silverkey/bgp_status_2.txt','r') as file:
#		f1 = file.readlines()
#		print (f1)
#	for line in bgp_status:
#		print (line)
		if re.search('never*',(bgp_status)):
			print ('no active neighbor found')
		elif re.search ('Established*',bgp_neighbor):
			print ('bgp is active',bgp_neighbor)
		else:
			print ('-----BGP is active-----\n',bgp_status)
	except:
		print('better luck next time')
		sys.exit()
command_list = ['show ip bgp summary','show ip bgp neighbors']

test_bgp()
