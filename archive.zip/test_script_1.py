#import modules
from netmiko import ConnectHandler
import os,sys,re

#dict out device
router_1 = {'host':'R1',
	  'device_type':'cisco_ios',
	  'username':'cisco',
	  'password':'cisco'}
router_2 = {'ip':'11.11.11.11',
	   'device_type':'cisco_ios',
	   'username':'cisco',
	   'password':'cisco'}
devices=[router_1,router_2]

#create function
def test_bgp():

	try:
		for device in devices:
			bgp_status=ConnectHandler(**device).send_command('show ip bgp summary')
			bgp_neighbor=ConnectHandler(**device).send_command('show ip bgp neighbors')
			interface=ConnectHandler(**device).send_command('show ip int bri')
			if re.search('never*',(bgp_status)):
				print ('No active neighbor found',bgp_status)
			elif re.search ('Established*',bgp_neighbor):
				print ('bgp is active',bgp_neighbor)
			else:
				try:
					def config_bgp():
						command_list_1 = ['router bgp ' + AS_1 , 'neigh ' + ipadd_2 + ' remote-as '+ AS_2 ]
						command_list_2 = ['router bgp ' + AS_2 , 'neigh ' + ipadd_1 + ' remote-as '+ AS_1 ]
						bgp_config_1=ConnectHandler(**router_1).send_config_set(command_list_1)
						bgp_config_2=ConnectHandler(**router_2).send_config_set(command_list_2)
						print ('done')
					AS_1=input('Please provide BGP AS for router 1: ')
					ipadd_1=input('Please provide neighbor ip address for router 1: ')
					AS_2=input('Please provode BGP AS for router 2: ')
					ipadd_2=input('Please provide neighbot ip address for router 2: ')
					config_bgp()
				except:
					print('didnt work')

	except:
		print('better luck next time')
		sys.exit()

test_bgp()
